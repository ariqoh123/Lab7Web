<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $title; ?></title>
</head>
<body>
    <?= $this->include('template/header'); ?>
    <section id="about">
        <div class="row">
            <h1>HOLAA !!!</h1>
            <p>Hello everyone My name is Muhammad Azizul Dzikri <b></b> See uuu :-) </p>
        </div>
    </section>
    <?= $this->include('template/footer'); ?>
</body>
</html>